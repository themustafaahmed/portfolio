using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using com.App.Repository;
using com.App.Data;
using Microsoft.AspNetCore.Authorization;

namespace app.Areas.Admin.Controllers
{
   // [Authorize(Roles = "Admin")]
    [Area("Admin")]
    public class AdminController : Controller
    {
        private IHostingEnvironment hosting;
        private DataBaseContext context;

        public AdminController(IHostingEnvironment _hosting, DataBaseContext _context)
        {
            hosting = _hosting;
            context = _context;
        }
        [HttpGet]
        [Route("[area]")]
        public IActionResult Index()
        {
            var unitOfWork = new UnitOfWork(context);
            return View();
        }

   }
}