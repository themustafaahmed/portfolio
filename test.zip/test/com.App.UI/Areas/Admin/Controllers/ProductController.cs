using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using com.App.Data.Models;
using com.App.Repository;
using com.App.Data;
using com.App.UI.Helpers;
using com.App.UI.Areas.Admin.Models;

namespace app.Areas.Admin.Controllers
{

    [Area("Admin")]
    public class ProductController : Controller
    {
        private DataBaseContext context;
        private IHostingEnvironment hosting;

        public ProductController(DataBaseContext _context, IHostingEnvironment _hosting)
        {
            context = _context;
            hosting = _hosting;
        }

        [HttpGet]
        [Route("[area]/[controller]")]
        [Route("[area]/[controller]/products")]
        public IActionResult Product()
        {
            var unitOfWork = new UnitOfWork(context);
            var product = unitOfWork.ProductRepository.GetProductWithImagesWithCategory();
            return View(product);
        }

        [HttpGet]
        [Route("[area]/[controller]/Create")]
        public IActionResult CreateProduct()
        {
            var unitOfWork = new UnitOfWork(context);
            var category = unitOfWork.CategoryRepository.GetAll();
            return View(category);
        }

        [HttpPost]
        [Route("[area]/[controller]/Create")]
        public async Task<IActionResult> CreateProduct(Product product, List<IFormFile> Image)
        {
            var unitOfWork = new UnitOfWork(context);
            var imageHelper = new ImageHelper(hosting);
            var imagePath = await imageHelper.SaveImages(Image);
            var imageList = new List<Images>();
            foreach (var imageUrl in imagePath)
            {
                imageList.Add(new Images
                {
                    Id = Guid.NewGuid().ToString(),
                    Url = imageUrl,
                    IsActive = product.IsActive,
                    CreatedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now
                });
            }
            product.Category = null;
            product.Images = imageList;
            product.CreatedDate = DateTime.Now;
            product.UpdatedDate = DateTime.Now;
            unitOfWork.ProductRepository.Add(product);
            unitOfWork.Complete();
            return Redirect("/admin/product");
        }

        [HttpGet]
        [Route("[area]/[controller]/Update/{id}")]
        public IActionResult UpdateProduct(string id)
        {
            var unitOfWork = new UnitOfWork(context);
            var product = unitOfWork.ProductRepository.GetProductWithImagesWithCategory().FirstOrDefault(x=>x.Id == id);
            var category = unitOfWork.CategoryRepository.GetAll();
            var productCategory = new ProductCategoryViewModel();
            productCategory.Product = product;
            productCategory.Category = category;
            return View(productCategory);
        }

        [HttpPost]
        [Route("[area]/[controller]/Update/{id?}")]
        public IActionResult UpdateProduct(Product product)
        {
            var unitOfWork = new UnitOfWork(context);
            product.Category = null;
            product.CreatedDate = DateTime.Now;
            product.UpdatedDate = DateTime.Now;
            unitOfWork.ProductRepository.Update(product);
            unitOfWork.Complete();
            return Redirect("/admin/product");
        }

        [HttpGet]
        [Route("[area]/[controller]/Delete/{id}")]
        public IActionResult DeleteProduct(string id)
        {
            var unitOfWork = new UnitOfWork(context);
            var product = unitOfWork.ProductRepository.GetProductWithImagesById(x => x.Id == id).FirstOrDefault();
            var images = product.Images.ToList();
            var imageHelper = new ImageHelper(hosting);
            imageHelper.DeleteImages(images);
            unitOfWork.ProductRepository.Remove(product);
            unitOfWork.Complete();
            return Redirect("/admin/product");
        }
    }
}