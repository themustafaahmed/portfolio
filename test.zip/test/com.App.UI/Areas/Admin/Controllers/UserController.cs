﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using com.App.Data;
using com.App.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace com.App.UI.Areas.Admin.Controllers
{
    public class UserController : Controller
    {
        private UserDbContext context;
        public UserController(UserDbContext _context)
        {
            context = _context;
        }

        [Area("Admin")]
        [HttpGet]
        [Route("[area]/[controller]")]
        public IActionResult User()
        {
            // var unitOfWork = new UnitOfWork(context.Users.);
            // var users = unitOfWork.UserRepository.GetAll();
            var users = context.Users.ToList();
            return View(users);
        }
    }
}