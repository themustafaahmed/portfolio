using System;
using Microsoft.AspNetCore.Mvc;
using com.App.Data.Models;
using com.App.Repository;
using com.App.Data;

namespace app.Areas.Admin.Controllers
{
    
    [Area("Admin")]
    public class RoleController: Controller
    {
        private static DataBaseContext context;

        public RoleController( DataBaseContext _context)
        {
            context = _context;
        }
        private UnitOfWork unitOfWork = new UnitOfWork(context);

        [HttpGet]
        public IActionResult AddRole(){

            return View();
        }
    }
}