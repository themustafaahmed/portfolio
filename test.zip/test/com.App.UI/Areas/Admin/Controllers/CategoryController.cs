using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using com.App.Data.Models;
using com.App.Repository;
using com.App.Data;
using com.App.UI.Areas.Admin.Models;

namespace app.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CategoryController : Controller
    {
        private DataBaseContext context;
        public CategoryController(DataBaseContext _context)
        {
            context = _context;
        }

        [HttpGet]
        [Route("[area]/[controller]")]
        [Route("[area]/[controller]/categories")]
        public IActionResult Category()
        {
            UnitOfWork unitOfWork = new UnitOfWork(context);
            var category = unitOfWork.CategoryRepository.GetAll();
            return View(category);
        }

        [HttpGet]
        [Route("[area]/[controller]/Create")]
        public IActionResult CreateCategory(){
            UnitOfWork unitOfWork = new UnitOfWork(context);
            var category = unitOfWork.CategoryRepository.GetAll();
            return View(category);
        } 

        [HttpPost]
        [Route("Admin/[controller]/Create")]
        public IActionResult CreateCategory(Category category){
            UnitOfWork unitOfWork = new UnitOfWork(context);
            if (category.Id == null){
                category.CreatedDate = DateTime.Now;
                category.UpdatedDate = DateTime.Now;
                unitOfWork.CategoryRepository.Add(category);
             }else{
                category.SubCategoryId = category.Id;
                category.Id = null;
                category.CreatedDate = DateTime.Now;
                category.UpdatedDate = DateTime.Now;
                unitOfWork.CategoryRepository.Add(category);
             }
            unitOfWork.Complete();
            return Redirect("/admin/category/Create");
        }

        [HttpGet]
        [Route("Admin/[controller]/Update/{id}")]
        public IActionResult UpdateCategory(string id){
            var unitOfWork = new UnitOfWork(context);
            var category = unitOfWork.CategoryRepository.Where(x=>x.Id == id).FirstOrDefault();
            var categories = unitOfWork.CategoryRepository.GetAll();
            var categoryViewModel = new CategoryViewModel();
            categoryViewModel.Categories = categories;
            categoryViewModel.Category = category;
            return View(categoryViewModel);
        }

        [HttpPost]
        [Route("Admin/[controller]/Update/{id?}")]
        public IActionResult UpdateCategory(Category category){
            var unitOfWork = new UnitOfWork(context);
            category.UpdatedDate = DateTime.Now;
            unitOfWork.CategoryRepository.Update(category);
            unitOfWork.Complete();
            return Redirect("/admin/category");
        }

        [HttpGet]
        [Route("Admin/[controller]/Delete/{id}")]
        public IActionResult DeleteCategory(string id){
            var unitOfWork = new UnitOfWork(context);
            var category = unitOfWork.CategoryRepository.Where(x=>x.Id == id).FirstOrDefault();
            unitOfWork.CategoryRepository.Remove(category);
            unitOfWork.Complete();
            return Redirect("/admin/category");
        }
    }
}