﻿using com.App.Data;
using com.App.Repository;
using com.App.UI.Helpers;
using Microsoft.AspNetCore.Mvc;

namespace com.App.UI.Areas.Admin.Controllers
{
    public class EmailController : Controller
    {
        private DataBaseContext context;
        public EmailController(DataBaseContext _context)
        {
            context = _context;
        }

        [Area("Admin")]
        [HttpGet]
        [Route("[area]/[controller]")]
        public IActionResult Email()
        {
            var unitOfWork = new UnitOfWork(context);
            var users = unitOfWork.UserRepository.GetAll();
            return View(users);
        }
        public IActionResult SendEmail()
        {
            var emailHelper = new EmailHelper();
           // emailHelper.SendEmail();

            return View();
        }

    }
}