﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using com.App.Data.Models;

namespace com.App.UI.Areas.Admin.Models
{
    public class ProductCategoryViewModel
    {
        public ProductCategoryViewModel()
        {
            Category = new List<Category>();
            Product = new Product();
        }
        public List<Category> Category { get; set; }

        public Product Product { get; set; }
    }
}
