﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using com.App.Data.Models;

namespace com.App.UI.Areas.Admin.Models
{
    public class CategoryViewModel
    {
        public CategoryViewModel()
        {
            Categories = new List<Category>();
            Category = new Category();
        }
        public ICollection<Category> Categories { get; set; }
        public Category Category { get; set; }
    }
}
