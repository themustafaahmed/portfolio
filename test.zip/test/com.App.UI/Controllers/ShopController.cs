using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using com.App.Repository;
using com.App.Data.Models;
using com.App.Data;
using com.App.UI.Models;

namespace app.Controllers
{
    public class ShopController : Controller
    {
        private  DataBaseContext context;

        public ShopController(DataBaseContext _context)
        {
            context = _context;
        }
       

        public IActionResult Shop()
        {
            UnitOfWork unitOfWork = new UnitOfWork(context);
           var products =  unitOfWork.ProductRepository.GetProductWithImages();
           var category = unitOfWork.CategoryRepository.GetAll();
           var categoryWithProduct = new CategoryWithProductView();

            categoryWithProduct.Category = category;
            categoryWithProduct.Product = products;
            return View(categoryWithProduct);
        }

        public IActionResult ProductDetails(string id)
        {
            UnitOfWork unitOfWork = new UnitOfWork(context);
            // var products =  this.unitOfWork.ProductRepository.Where(x=>x.Id == id).FirstOrDefault();
            var products =  unitOfWork.ProductRepository.GetProductWithImagesById(x=>x.Id == id);
            //var category = unitOfWork.CategoryRepository.GetCategoryWithSubCategory("/" + id);
            var categoryWithProduct = new CategoryWithProductView();
           // categoryWithProduct.Category = category;
            categoryWithProduct.Product = products;
            return View(categoryWithProduct);
        }

        [HttpGet("/shop/category/{id?}/{subcategory?}")]
        public IActionResult Category(string id, string subcategory){
            UnitOfWork unitOfWork = new UnitOfWork(context);
            var categoryWithProduct = new CategoryWithProductView();
            List<Product> products = null;

            if(subcategory != null){
              //  products = unitOfWork.ProductRepository
              //  .GetProductWithImagesWithCategoryWithSubCategoryByUrl("/"+id,"/"+subcategory);
            }else{
              //  products = unitOfWork.ProductRepository
              //  .GetProductWithImagesWithCategoryWithSubCategoryByUrl("/" + id);
                
            }
            //var categoryEntity = unitOfWork.CategoryRepository.GetCategoryWithSubCategory("/" + id);
            
            //categoryWithProduct.Category = categoryEntity;
            categoryWithProduct.Product = products;
            

            return View(categoryWithProduct);
        }
    }
}