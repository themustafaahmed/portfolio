using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using com.App.Repository;
using com.App.Data.Models;
using com.App.Data;
using com.App.UI.Helpers;

namespace com.App.UI.Controllers
{

    //[AuthorizeAttribute]
    public class CheckoutController : Controller
    {
        private DataBaseContext context;

        public CheckoutController(DataBaseContext _context)
        {
            context = _context;
        }
    
        TotalPrice total = new TotalPrice();
        public IActionResult Checkout()
        {
            UnitOfWork unitOfWork = new UnitOfWork(context);
            var getCart = SessionHelper
                .GetObjectAsJson<List<CartItems>>(HttpContext.Session,"CartItems");
            if(getCart != null){
                var list = new List<String>();
                foreach(var item in getCart){
                    list.Add(item.ProductId);
                }
                var product = unitOfWork.ProductRepository.GetProductWithImagesById(x=>list.Contains(x.Id));
                var productWithCount = new List<Cart>();

                int index=0;
                foreach(var item in product){
                    var search = getCart.FirstOrDefault(x=>x.ProductId == item.Id);
                   // productWithCount.Add(new Cart{Product = product[index],
                   // ProductCount = search.CountItem,
                  //  TotalPrice = search.CountItem * product[index].Price});
                    index++;
                }
                //var totalPrice = productWithCount.Sum(x=>x.Product.Price * x.ProductCount);
               
                total.Cart = productWithCount;
                //total.Total = totalPrice;

                return View(total);
            }
            return Redirect("/shop/category");
        }

        [HttpPost]
        public IActionResult CheckoutFinish(){

            UnitOfWork unitOfWork = new UnitOfWork(context);
 
            return Redirect("/");
        }
    }
}