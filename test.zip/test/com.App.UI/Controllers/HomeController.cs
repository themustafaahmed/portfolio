﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using com.App.Repository;
using com.App.Data;
using com.App.UI.Models;

namespace com.App.UI.Controllers
{
    public class HomeController : Controller
    {

        private DataBaseContext context;

        public HomeController(DataBaseContext _context)
        {
            context = _context;
        }
       
        public IActionResult Index()
        {
            UnitOfWork unitOfWork = new UnitOfWork(context);
            var products = unitOfWork.ProductRepository.GetProductWithImages();
            var category = unitOfWork.CategoryRepository.GetAll();

            var categoryWithProduct = new CategoryWithProductView();
            categoryWithProduct.Category = category;
            categoryWithProduct.Product = products;
            
            return View(categoryWithProduct);
        }

        public IActionResult Search(string search)
        {

            // if (!String.IsNullOrEmpty(searchString))
            // {
            //     movies = movies.Where(s => s.Title.Contains(searchString));
            // }
            UnitOfWork unitOfWork = new UnitOfWork(context);
            //var products = unitOfWork.ProductRepository.GetProductWithImagesById(
             //   x=>x.Title.Contains(search));
            var category = unitOfWork.CategoryRepository.GetAll();

            var categoryWithProduct = new CategoryWithProductView();
            categoryWithProduct.Category = category;
           // categoryWithProduct.Product = products;

            return View("Index",categoryWithProduct);
        }

        public IActionResult About()
        {

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }
}
