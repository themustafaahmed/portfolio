using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using com.App.Data;
using com.App.Repository;
using com.App.Data.Models;
using com.App.UI.Helpers;

namespace com.App.UI.Controllers
{

    public class CartController : Controller
    {
        private static DataBaseContext context;

        public CartController(DataBaseContext _context)
        {
            context = _context;
        }
        
        public IActionResult Cart()
        {
            UnitOfWork unitOfWork = new UnitOfWork(context);
            var getCart = SessionHelper
                .GetObjectAsJson<List<CartItems>>(HttpContext.Session,"CartItems");
            if(getCart != null){
                var list = new List<String>();
                foreach(var item in getCart){
                    list.Add(item.ProductId);
                }
                var product = unitOfWork.ProductRepository.GetProductWithImagesById(x=>list.Contains(x.Id));
                var productWithCount = new List<Cart>();

                int index=0;
                foreach(var item in product){
                    var search = getCart.FirstOrDefault(x=>x.ProductId == item.Id);
                  //  productWithCount.Add(new Cart{Product = product[index],
                  //  ProductCount = search.CountItem,
                  //  TotalPrice = search.CountItem * product[index].Price});
                    index++;
                }
               // var totalPrice = productWithCount.Sum(x=>x.Product.Price * x.ProductCount);
                var total = new TotalPrice();
                total.Cart = productWithCount;
            //    total.Total = totalPrice;

                return View(total);
            }else{
                 return View();
            }
        }

        public void AddCart(string id, int quantity = 0){

            if(id == "undefined" || id == null){
                return;
            }
            int quantityCount;
            if(quantity == 0 || quantity == 1){
                quantityCount = 1;
            }else{
                quantityCount = quantity;
            }
           
            if(SessionHelper.GetObjectAsJson<List<CartItems>>
                (HttpContext.Session,"CartItems") == null){
                var cart = new List<CartItems>();
                cart.Add(new CartItems{ProductId = id, CountItem = quantityCount});
                SessionHelper.SetObjectAsJson(HttpContext.Session,"CartItems",cart);
            }else{
                var listingItems = new List<CartItems>();
                var session = SessionHelper.GetObjectAsJson<List<CartItems>>
                (HttpContext.Session,"CartItems");

                foreach(var item in session){
                    listingItems.Add(new CartItems{ProductId = item.ProductId,
                    CountItem = item.CountItem});
                }
                if(listingItems.FirstOrDefault(x=>x.ProductId == id) != null){
                    var item = listingItems.FirstOrDefault(x=>x.ProductId == id);
                    var itemNumber = item.CountItem;
                    listingItems.Remove(item);
                    listingItems.Add(new CartItems{ProductId = id,CountItem =itemNumber+quantityCount});
                }else{
                    listingItems.Add(new CartItems{ProductId = id,CountItem = quantityCount});
                }
                SessionHelper.SetObjectAsJson(HttpContext.Session,"CartItems",listingItems);
            }
        }
    
        public void RemoveCart(string id){
            if(id == null){
                return;
            }
            var session = SessionHelper.GetObjectAsJson<List<CartItems>>
                (HttpContext.Session,"CartItems");
            var listItem = new List<CartItems>();
            foreach(var list in session){
                listItem.Add(new CartItems{ProductId = list.ProductId,CountItem=list.CountItem});
            }
            var item = listItem.FirstOrDefault(x=>x.ProductId == id);
            listItem.Remove(item);
            SessionHelper.SetObjectAsJson(HttpContext.Session,"CartItems",listItem);  
        }
    }
}