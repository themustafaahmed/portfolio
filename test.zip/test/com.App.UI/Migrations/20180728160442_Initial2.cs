﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace com.App.UI.Migrations
{
    public partial class Initial2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Category_Category_SubCategoryId",
                table: "Category");

            migrationBuilder.RenameColumn(
                name: "SubCategoryId",
                table: "Category",
                newName: "CategoryId");

            migrationBuilder.RenameIndex(
                name: "IX_Category_SubCategoryId",
                table: "Category",
                newName: "IX_Category_CategoryId");

            migrationBuilder.AddForeignKey(
                name: "FK_Category_Category_CategoryId",
                table: "Category",
                column: "CategoryId",
                principalTable: "Category",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Category_Category_CategoryId",
                table: "Category");

            migrationBuilder.RenameColumn(
                name: "CategoryId",
                table: "Category",
                newName: "SubCategoryId");

            migrationBuilder.RenameIndex(
                name: "IX_Category_CategoryId",
                table: "Category",
                newName: "IX_Category_SubCategoryId");

            migrationBuilder.AddForeignKey(
                name: "FK_Category_Category_SubCategoryId",
                table: "Category",
                column: "SubCategoryId",
                principalTable: "Category",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
