﻿using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace com.App.UI.Helpers
{
    public class EmailHelper
    {
        public async Task SendEmail(string body, string subject, string to, string from,
            string stpClient,string username,string password)
        {
            using (SmtpClient smtpClient = new SmtpClient(stpClient))
            {
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new NetworkCredential(username, password);
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(from);
                mailMessage.To.Add(to);
                mailMessage.Body = body;
                mailMessage.Subject = subject;
                smtpClient.Send(mailMessage);
            }
            await Task.CompletedTask;
        }
    }
}
