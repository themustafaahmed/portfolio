﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using com.App.Data.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;

namespace com.App.UI.Helpers
{
    public class ImageHelper
    {
        private IHostingEnvironment hosting;
        public ImageHelper(IHostingEnvironment _hosting)
        {
            hosting = _hosting;
        }
        public async Task<List<String>> SaveImages(List<IFormFile> images)
        {
            string path = Path.Combine(hosting.WebRootPath, "uploads");
            var list = new List<String>();
            foreach (var image in images)
            {
                string fileName = image.FileName;
                string[] formatSplit = fileName.Split(".");
                string fileFormat = "." + formatSplit[1];
                string uniqueUrl = Guid.NewGuid().ToString();
                using (FileStream fileStream = new FileStream(Path.Combine(path, uniqueUrl + fileFormat), FileMode.Create))
                {
                    await image.CopyToAsync(fileStream);
                }
                list.Add(Path.Combine(uniqueUrl + fileFormat));
            }
            return list;
        }

        public void DeleteImages(List<Images> images)
        {
            string path = Path.Combine(hosting.WebRootPath,"uploads");
            foreach (var image in images)
            {
                var imgurl = Path.Combine(path + image.Url);
                var file = new FileInfo(imgurl);
                file.Delete();
            }
        }
    }
}
