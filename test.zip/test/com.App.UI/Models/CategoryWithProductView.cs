using System.Collections.Generic;
using com.App.Data.Models;

namespace com.App.UI.Models
{
    public class CategoryWithProductView
    {
        public IEnumerable<Product> Product { get; set; }
        public IEnumerable<Category> Category { get; set; }
    }
}