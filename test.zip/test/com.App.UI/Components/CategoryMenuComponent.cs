using com.App.Data;
using com.App.Repository;
using Microsoft.AspNetCore.Mvc;

namespace com.App.UI.Components
{
    public class CategoryMenuComponent:ViewComponent
    {
        private DataBaseContext context;

        public CategoryMenuComponent(DataBaseContext _context)
        {
            context = _context;
        }
        
        public IViewComponentResult Invoke(){

            UnitOfWork unitOfWork = new UnitOfWork(context);
            //var category = unitOfWork.CategoryRepository.GetCategoryWithSubCategory();

            return View();
        }
    }
}