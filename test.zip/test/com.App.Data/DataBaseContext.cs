using com.App.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace com.App.Data
{
    public class DataBaseContext:DbContext
    {
        public DataBaseContext(DbContextOptions<DataBaseContext> options) :base(options)
        {
          
        }
        public DbSet<Customer> Customers { get; set; }

        public DbSet<Product> Products { get; set; }
        
        public DbSet<Images> Images { get; set; }

        public DbSet<Category> Category{ get; set; }

        public DbSet<Order> Orders { get; set; }
        

        // protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //  => optionsBuilder.UseMySQL(@"Server=localhost;port=3306;database=Shoping;user=root;password=123;SslMode=none");


    }
}