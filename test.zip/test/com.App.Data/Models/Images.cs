namespace com.App.Data.Models
{
    public class Images : BaseEntity
    {
        public Images()
        {
            Product = new Product();
        }
        public string Url { get; set; }

        public Product Product { get; set; }
    }
}