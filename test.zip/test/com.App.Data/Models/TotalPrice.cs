using System.Collections.Generic;

namespace com.App.Data.Models
{
    public class TotalPrice
    {
        public List<Cart> Cart{ get; set; }
        public decimal Total { get; set; }
    }
}