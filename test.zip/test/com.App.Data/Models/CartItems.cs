namespace com.App.Data.Models
{
    public class CartItems : BaseEntity
    {
        public string ProductId { get; set; }

        public int CountItem { get; set; }
    }
}