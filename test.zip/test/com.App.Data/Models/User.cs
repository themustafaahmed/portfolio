﻿using Microsoft.AspNetCore.Identity;

namespace com.App.Data.Models
{
    public class User : IdentityUser
    {
        public string Adress { get; set; }
    }
}
