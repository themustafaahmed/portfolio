using System;
namespace com.App.Data.Models
{
    public class BaseEntity
    {
        public string Id { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public bool? IsActive {get;set;}
        
    }
}