namespace com.App.Data.Models
{
    public class Order : BaseEntity
    {
        public string CustomerId { get; set; }
        public Customer Customer { get; set; }
        public string ProductId { get; set; }
        public Product Product { get; set; }
        public int ProductCount { get; set; }
    }
}