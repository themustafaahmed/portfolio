using System.Collections.Generic;

namespace com.App.Data.Models
{
    public class Category : BaseEntity
    {
        public Category()
        {
            Product = new List<Product>();
            //SubCategory = new List<Category>();
        }
        public string Name { get; set; }

        public string Description { get; set; }

        public string Url { get; set; }

        public List<Product> Product { get; set; }

        public string SubCategoryId { get; set; }

    }
}