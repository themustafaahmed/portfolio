using System.Collections.Generic;

namespace com.App.Data.Models
{
    public class Cart : BaseEntity
    {
        public ICollection<Product> Product { get; set; }
        public int Quantity { get; set; }
       /// public decimal TotalPrice { get; set; }
    }
}