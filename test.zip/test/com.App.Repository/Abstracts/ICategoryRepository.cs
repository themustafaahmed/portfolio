using System.Collections.Generic;
using com.App.Data.Models;

namespace com.App.Repository.Abstracts
{
    public interface ICategoryRepository : IRepository<Category>
    {
        
    }
}