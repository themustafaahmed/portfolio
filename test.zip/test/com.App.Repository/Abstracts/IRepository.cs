using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace com.App.Repository.Abstracts
{
    public interface IRepository<T> where T : class
    {
        IList<T> Where(Expression<Func<T, bool>> predicate);
        List<T> GetAll();
        void Add(T entity);
        void AddRange(IEnumerable<T> entity);
        void Update(T entity);
        void Remove(T entity);
        void RemoveRange(IEnumerable<T> entity);
      
    }
}