using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using com.App.Data.Models;

namespace com.App.Repository.Abstracts
{
    public interface IProductRepository:IRepository<Product>
    {
          IEnumerable<Product> GetProductWithImages();

          List<Product> GetProductWithImagesById(Expression<Func<Product, bool>> predicate);

          List<Product> GetProductWithImagesWithCategory();

         
        
    }

    
}