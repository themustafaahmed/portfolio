using com.App.Data.Models;

namespace com.App.Repository.Abstracts
{
    public interface IImageRepository : IRepository<Images>
    {
         
    }
}