using com.App.Data.Models;

namespace com.App.Repository.Abstracts
{
    public interface IOrderRepository : IRepository<Order>
    {
         
    }
}