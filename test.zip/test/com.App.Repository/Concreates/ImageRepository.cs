using com.App.Data;
using com.App.Data.Models;
using com.App.Repository.Abstracts;

namespace com.App.Repository.Concreates
{
    public class ImageRepository : Repository<Images>, IImageRepository
    {
        public ImageRepository(DataBaseContext context) : base(context)
        {
        }
    }
}