using com.App.Data;
using com.App.Data.Models;
using com.App.Repository.Abstracts;

namespace com.App.Repository.Concreates
{
    public class UserRepository : Repository<User>, IUserRepository
    {

        private DataBaseContext context;
        public UserRepository(DataBaseContext context) : base(context)
        {
            this.context = context;
        }

        
    }
}