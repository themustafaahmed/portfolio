using System.Collections.Generic;
using System.Linq;
using com.App.Data;
using com.App.Data.Models;
using com.App.Repository.Abstracts;
using Microsoft.EntityFrameworkCore;

namespace com.App.Repository.Concreates
{
    public class CategoryRepository : Repository<Category>, ICategoryRepository
    {

        private DataBaseContext context;
        public CategoryRepository(DataBaseContext context) : base(context)
        {
            this.context = context;
        }
        
    }
}