using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using com.App.Data;
using com.App.Repository.Abstracts;

namespace com.App.Repository.Concreates
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private DataBaseContext context;
        public Repository(DataBaseContext context)
        {
            this.context = context;
        }
        public void Add(T entity)
        {
            context.Set<T>().Add(entity);
        }

        public void AddRange(IEnumerable<T> entity)
        {
            context.Set<T>().AddRange(entity);
           
        }

        public List<T> GetAll()
        {
            return context.Set<T>().ToList();
        }

        public IList<T> Where(Expression<Func<T, bool>> predicate)
        {
            return context.Set<T>().Where(predicate).ToList();
        }

        public void Remove(T entity)
        {
            context.Set<T>().Remove(entity);
        }

        public void RemoveRange(IEnumerable<T> entity)
        {
            context.Set<T>().RemoveRange(entity);
        }

        public void Update(T entity)
        {
            context.Set<T>().Update(entity);
        }
    }
}