using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using com.App.Data;
using com.App.Data.Models;
using com.App.Repository.Abstracts;
using Microsoft.EntityFrameworkCore;

namespace com.App.Repository.Concreates
{
    public class ProductRepository : Repository<Product>,IProductRepository
    {

        private DataBaseContext context;

        public ProductRepository(DataBaseContext context) : base(context) 
        {
            this.context = context;
        }

        public IEnumerable<Product> GetProductWithImages(){

          return context.Products.Include(x=>x.Images).ToList();
        }

        public List<Product> GetProductWithImagesById(Expression<Func<Product, bool>> predicate){

            return context.Products.Include(x=>x.Images).Where(predicate).ToList();
        }

        public List<Product> GetProductWithImagesWithCategory(){

             return context.Products.Include(x=>x.Images).Include(x=>x.Category)
            .ToList();
        }

    }
}