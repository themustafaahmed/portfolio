using com.App.Data;
using com.App.Data.Models;
using com.App.Repository.Abstracts;

namespace com.App.Repository.Concreates
{
    public class OrderRepository : Repository<Order>, IOrderRepository
    {
        public OrderRepository(DataBaseContext context) : base(context)
        {
        }
    }
}