using com.App.Data;
using com.App.Repository.Abstracts;
using com.App.Repository.Concreates;

namespace com.App.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        DataBaseContext dataBaseContext;
        public UnitOfWork(DataBaseContext dataBaseContext)
        {
            this.dataBaseContext = dataBaseContext;
            ProductRepository = new ProductRepository(dataBaseContext);
            UserRepository = new UserRepository(dataBaseContext);
            ImageRepository = new ImageRepository(dataBaseContext);
            CategoryRepository = new CategoryRepository(dataBaseContext);
            OrderRepository = new OrderRepository(dataBaseContext);
        }
        public IProductRepository ProductRepository { get; private set; }

        public IUserRepository UserRepository { get; private set; }

        public IImageRepository ImageRepository { get; private set; }

        public ICategoryRepository CategoryRepository { get; private set; }

        public IOrderRepository OrderRepository { get; private set; }

        public int Complete()
        {
            return dataBaseContext.SaveChanges();
        }

        public void Dispose()
        {
            dataBaseContext.Dispose();
        }
    }
}