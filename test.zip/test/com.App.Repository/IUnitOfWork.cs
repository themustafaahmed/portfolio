using System;
using com.App.Repository.Abstracts;

namespace com.App.Repository
{
    public interface IUnitOfWork : IDisposable
    {
          IProductRepository ProductRepository { get; }
          IUserRepository UserRepository { get; }
          IImageRepository ImageRepository { get; }
          ICategoryRepository CategoryRepository{ get; }
          IOrderRepository OrderRepository{ get; }
          int Complete();
    }
}